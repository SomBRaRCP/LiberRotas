"""Administrative helper to set the Firebase custom role claim."""

from __future__ import annotations

import argparse

from firebase_admin import auth

from .auth import FirebaseAuthenticator
from .config import get_settings


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Set LiberRotas Firebase role custom claim")
    parser.add_argument("uid")
    parser.add_argument("role", choices=["entrepreneur", "visitor"])
    args = parser.parse_args(argv)
    FirebaseAuthenticator(get_settings())
    user = auth.get_user(args.uid)
    claims = dict(user.custom_claims or {})
    claims["role"] = args.role
    auth.set_custom_user_claims(args.uid, claims)
    print(f"Updated role claim for UID {args.uid}")


if __name__ == "__main__":
    main()
