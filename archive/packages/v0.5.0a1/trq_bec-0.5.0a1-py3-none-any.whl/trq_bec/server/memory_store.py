"""Thread-safe durable-store test double used by API regression tests."""

from __future__ import annotations

import base64
import threading
import uuid
from dataclasses import replace
from typing import Any

from ..canonical import domain_message, sha3_hex
from ..errors import LedgerError
from .models import AuditRecord, CouponRecord, DeviceRecord, OperationRecord, TokenRecord
from .store import StoreConflict


class MemoryDurableStore:
    def __init__(self, signing_provider) -> None:
        self.signing_provider = signing_provider
        self.devices: dict[str, DeviceRecord] = {}
        self.coupons = {
            f"FEITUR-{number:03d}": CouponRecord(f"FEITUR-{number:03d}", None, True, None)
            for number in range(1, 5)
        }
        self.tokens: dict[str, TokenRecord] = {}
        self.operations: dict[str, OperationRecord] = {}
        self.events: list[dict[str, Any]] = []
        self._lock = threading.RLock()

    def ping(self) -> bool:
        return True

    def enroll_device(self, uid: str, key_id: str, public_key_b64u: str, algorithm: str, storage_profile: str):
        with self._lock:
            current = self.devices.get(key_id)
            if current:
                if current.firebase_uid != uid or current.public_key_b64u != public_key_b64u:
                    raise StoreConflict("DEVICE_KEY_BINDING_CONFLICT")
                return current, False
            if any(item.firebase_uid == uid and item.public_key_b64u == public_key_b64u for item in self.devices.values()):
                raise StoreConflict("DEVICE_PUBLIC_KEY_ALREADY_BOUND")
            record = DeviceRecord(uid, key_id, public_key_b64u, algorithm, "ACTIVE")
            self.devices[key_id] = record
            return record, True

    def get_device(self, uid: str, key_id: str):
        with self._lock:
            item = self.devices.get(key_id)
            return item if item and item.firebase_uid == uid and item.status == "ACTIVE" else None

    def get_coupon_for_issue(self, coupon_id: str, owner_uid: str):
        item = self.coupons.get(coupon_id)
        return item if item and item.active and (item.owner_uid is None or item.owner_uid == owner_uid) else None

    def store_token(self, token: TokenRecord) -> None:
        with self._lock:
            if token.token_ref in self.tokens:
                raise StoreConflict("TOKEN_REFERENCE_EXISTS")
            self.tokens[token.token_ref] = token

    def get_token(self, token_ref: str):
        with self._lock:
            return self.tokens.get(token_ref)

    def create_operation(self, operation: OperationRecord) -> None:
        with self._lock:
            if operation.operation_id in self.operations:
                raise StoreConflict("OPERATION_EXISTS")
            self.operations[operation.operation_id] = operation

    def get_operation(self, operation_id: str):
        with self._lock:
            return self.operations.get(operation_id)

    def append_audit(self, **kwargs: Any) -> AuditRecord:
        with self._lock:
            seq = len(self.events) + 1
            previous = self.events[-1]["event_hash"] if self.events else "0" * 64
            event_id = str(uuid.uuid4())
            body = {
                "event_id": event_id,
                "seq": seq,
                "operation_id": kwargs["operation_id"],
                "suite_id": kwargs["suite_id"],
                "key_ref_token": kwargs["key_ref_token"],
                "event_type": kwargs["event_type"],
                "result": kwargs["result"],
                "reason_codes": list(kwargs.get("reason_codes", ())),
                "evidence_refs": list(kwargs.get("evidence_refs", ())),
                "details": kwargs.get("details", {}),
                "prev_hash": previous,
            }
            event_hash = sha3_hex(body, "TRQ-BEC/audit/v1")
            self.events.append({**body, "event_hash": event_hash})
            return AuditRecord(f"event:{event_id}", seq, event_hash)

    def finalize_authorization(self, operation_id: str, token_ref: str, decision: str, result: dict[str, Any], **audit: Any):
        with self._lock:
            operation = self.operations.get(operation_id)
            token = self.tokens.get(token_ref)
            if operation is None or token is None:
                raise StoreConflict("OPERATION_OR_TOKEN_MISSING")
            if operation.status != "PENDING":
                raise StoreConflict("OPERATION_ALREADY_COMPLETED")
            if decision == "ALLOW":
                if token.status != "ISSUED":
                    raise StoreConflict("TOKEN_ALREADY_USED_OR_EXPIRED")
                self.tokens[token_ref] = replace(token, status="REDEEMED", redeemed_operation_id=operation_id)
            elif decision == "HOLD_OR_REVIEW":
                self.tokens[token_ref] = replace(token, status="HELD", redeemed_operation_id=operation_id)
            event = self.append_audit(operation_id=operation_id, result=decision, **audit)
            status = {
                "ALLOW": "COMPLETED",
                "STEP_UP": "STEP_UP_REQUIRED",
                "HOLD_OR_REVIEW": "HELD",
                "DENY": "DENIED",
            }[decision]
            self.operations[operation_id] = replace(
                operation,
                status=status,
                result={**result, "event_ref": event.event_id},
            )
            return event

    def create_checkpoint(self, checkpoint_key_id: str, policy_version: str):
        with self._lock:
            if not self.events:
                raise LedgerError("LEDGER_EMPTY")
            body = {
                "first_seq": 1,
                "last_seq": len(self.events),
                "root_hash": self.events[-1]["event_hash"],
                "policy_version": policy_version,
            }
            signature = self.signing_provider.sign(
                checkpoint_key_id,
                domain_message("TRQ-BEC/checkpoint/v1", body),
                "checkpoint-signing",
            )
            return {
                **body,
                "checkpoint_id": str(uuid.uuid4()),
                "signature_b64u": base64.urlsafe_b64encode(signature).rstrip(b"=").decode("ascii"),
            }
