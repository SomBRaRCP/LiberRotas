"""Environment-only backend configuration with production guards."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class ServerSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="TRQ_BEC_",
        extra="ignore",
        case_sensitive=False,
    )

    environment: Literal["development", "test", "production"] = "development"
    host: str = "0.0.0.0"
    port: int = Field(default=8787, ge=1, le=65535)
    workers: int = Field(default=1, ge=1, le=32)
    log_level: str = "info"
    forwarded_allow_ips: str = "127.0.0.1"

    database_url: str = "postgresql://trq_bec:trq_bec@127.0.0.1:5432/trq_bec"
    redis_url: str = "redis://127.0.0.1:6379/0"
    database_pool_min: int = Field(default=2, ge=1, le=50)
    database_pool_max: int = Field(default=10, ge=1, le=100)

    firebase_credentials_path: Path | None = None
    firebase_project_id: str | None = None
    firebase_check_revoked: bool = True

    issuer: str = "trq-bec.liberrotas.local"
    audience: str = "app-liberrotas"
    policy_version: str = "liberrotas-policy-1"
    token_ttl_seconds: int = Field(default=90, ge=15, le=300)
    challenge_ttl_seconds: int = Field(default=45, ge=10, le=120)
    replay_ttl_seconds: int = Field(default=600, ge=120, le=86_400)
    operation_ttl_seconds: int = Field(default=120, ge=30, le=600)
    rate_window_seconds: int = Field(default=60, ge=10, le=3600)
    rate_high_threshold: int = Field(default=10, ge=2, le=1000)

    issuer_private_key_path: Path | None = None
    checkpoint_private_key_path: Path | None = None
    audit_hmac_key_path: Path | None = None
    issuer_key_id: str = "issuer-lab-2026-01"
    checkpoint_key_id: str = "checkpoint-lab-2026-01"
    lab_suite_enabled: bool = True

    pqc_provider_name: str = "UNAVAILABLE"
    pqc_provider_version: str = "0"
    pqc_provider_approved: bool = False

    cors_origins: str = "http://localhost:8081,http://localhost:19006"
    docs_enabled: bool = True

    @property
    def cors_origin_list(self) -> list[str]:
        return [item.strip() for item in self.cors_origins.split(",") if item.strip()]

    @model_validator(mode="after")
    def production_guards(self) -> "ServerSettings":
        if self.database_pool_min > self.database_pool_max:
            raise ValueError("database_pool_min cannot exceed database_pool_max")
        if self.environment == "production":
            required = {
                "firebase_credentials_path": self.firebase_credentials_path,
                "issuer_private_key_path": self.issuer_private_key_path,
                "checkpoint_private_key_path": self.checkpoint_private_key_path,
                "audit_hmac_key_path": self.audit_hmac_key_path,
            }
            missing = [name for name, value in required.items() if value is None]
            if missing:
                raise ValueError(f"production configuration missing: {', '.join(missing)}")
            if self.lab_suite_enabled:
                raise ValueError("lab_suite_enabled must be false in production")
            if not self.pqc_provider_approved:
                raise ValueError("production requires an explicitly approved PQC provider")
        return self


@lru_cache(maxsize=1)
def get_settings() -> ServerSettings:
    return ServerSettings()
