"""Strict HTTP and persistence contracts."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class EnrollDeviceRequest(StrictModel):
    device_key_id: str = Field(min_length=12, max_length=160, pattern=r"^device:[A-Za-z0-9:_-]+$")
    public_key_b64u: str = Field(min_length=43, max_length=43, pattern=r"^[A-Za-z0-9_-]+$")
    algorithm: Literal["ED25519_LAB"]
    storage_profile: Literal["EXPO_SECURE_STORE_LAB"]


class EnrollDeviceResponse(StrictModel):
    device_key_id: str
    status: Literal["ENROLLED", "ALREADY_ENROLLED"]
    key_ref: str


class IssueCouponRequest(StrictModel):
    coupon_id: str = Field(pattern=r"^FEITUR-\d{3}$")
    issuer_id: str = Field(min_length=1, max_length=128)
    city: str = Field(min_length=1, max_length=120)
    device_key_id: str = Field(min_length=12, max_length=160)


class CompactQrPayload(StrictModel):
    type: Literal["trq-bec-coupon-v1"] = "trq-bec-coupon-v1"
    v: Literal[1] = 1
    token_ref: str = Field(min_length=22, max_length=128, pattern=r"^[A-Za-z0-9_-]+$")
    issuer_ref: str = Field(min_length=1, max_length=160)
    expires_at: int


class IssueCouponResponse(StrictModel):
    qr_payload: CompactQrPayload
    expires_at: int


class BeginRedemptionRequest(StrictModel):
    qr_payload: CompactQrPayload
    device_key_id: str = Field(min_length=12, max_length=160)


class ChallengeResponse(StrictModel):
    challenge_id: str
    expires_at: int


class BeginRedemptionResponse(StrictModel):
    operation_id: str
    session_id: str
    challenge: ChallengeResponse
    proof_message_b64u: str


class AuthorizeRedemptionRequest(StrictModel):
    operation_id: str = Field(min_length=8, max_length=160)
    session_id: str = Field(min_length=8, max_length=160)
    challenge_id: str = Field(min_length=16, max_length=160)
    device_key_id: str = Field(min_length=12, max_length=160)
    device_proof_b64u: str = Field(min_length=86, max_length=88, pattern=r"^[A-Za-z0-9_-]+$")


class AuthorizationResponse(StrictModel):
    decision: Literal["DENY", "ALLOW", "STEP_UP", "HOLD_OR_REVIEW"]
    operation_id: str
    crypto_ok: bool
    reason_codes: list[str]
    coupon_id: str | None = None
    event_ref: str | None = None
    idempotent: bool = False


class HealthResponse(StrictModel):
    status: Literal["ok", "degraded"]
    database: bool
    redis: bool
    crypto_provider: str
    pqc_ready: bool


@dataclass(frozen=True, slots=True)
class Principal:
    uid: str
    role: str | None
    email: str | None
    claims: dict[str, Any]

    @property
    def is_entrepreneur(self) -> bool:
        return self.role == "entrepreneur"

    @property
    def is_admin(self) -> bool:
        return bool(self.claims.get("admin"))


@dataclass(frozen=True, slots=True)
class DeviceRecord:
    firebase_uid: str
    device_key_id: str
    public_key_b64u: str
    algorithm: str
    status: str


@dataclass(frozen=True, slots=True)
class CouponRecord:
    coupon_id: str
    owner_uid: str | None
    active: bool
    valid_until: int | None


@dataclass(frozen=True, slots=True)
class TokenRecord:
    token_ref: str
    issuer_uid: str
    issuer_ref: str
    coupon_id: str
    intent: dict[str, Any]
    envelope: dict[str, Any]
    expires_at: int
    status: str
    redeemed_operation_id: str | None


@dataclass(frozen=True, slots=True)
class OperationRecord:
    operation_id: str
    firebase_uid: str
    session_id: str
    token_ref: str
    device_key_id: str
    challenge_id: str
    expires_at: int
    status: str
    result: dict[str, Any] | None


@dataclass(frozen=True, slots=True)
class AuditRecord:
    event_id: str
    seq: int
    event_hash: str
