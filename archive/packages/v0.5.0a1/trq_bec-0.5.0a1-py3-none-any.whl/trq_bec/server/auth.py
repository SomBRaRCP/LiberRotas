"""Firebase ID-token verification boundary."""

from __future__ import annotations

from typing import Protocol

import firebase_admin
from fastapi import Header, HTTPException, Request, status
from firebase_admin import auth, credentials

from .config import ServerSettings
from .models import Principal


class Authenticator(Protocol):
    def verify(self, bearer_token: str) -> Principal: ...


class FirebaseAuthenticator:
    def __init__(self, settings: ServerSettings) -> None:
        self.settings = settings
        try:
            firebase_admin.get_app()
            initialized = True
        except ValueError:
            initialized = False
        if not initialized:
            options = {"projectId": settings.firebase_project_id} if settings.firebase_project_id else None
            if settings.firebase_credentials_path:
                credential = credentials.Certificate(str(settings.firebase_credentials_path))
            else:
                credential = credentials.ApplicationDefault()
            firebase_admin.initialize_app(credential, options)

    def verify(self, bearer_token: str) -> Principal:
        try:
            claims = auth.verify_id_token(bearer_token, check_revoked=self.settings.firebase_check_revoked)
        except Exception as exc:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="AUTH_TOKEN_INVALID") from exc
        uid = claims.get("uid") or claims.get("sub")
        if not isinstance(uid, str) or not uid:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="AUTH_SUBJECT_INVALID")
        role = claims.get("role") or claims.get("account_type")
        return Principal(
            uid=uid,
            role=role if isinstance(role, str) else None,
            email=claims.get("email") if isinstance(claims.get("email"), str) else None,
            claims=dict(claims),
        )


def extract_bearer(authorization: str | None) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="AUTH_BEARER_REQUIRED")
    token = authorization[7:].strip()
    if not token or len(token) > 8192:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="AUTH_BEARER_INVALID")
    return token


def require_principal(request: Request, authorization: str | None = Header(default=None)) -> Principal:
    authenticator: Authenticator = request.app.state.authenticator
    return authenticator.verify(extract_bearer(authorization))
