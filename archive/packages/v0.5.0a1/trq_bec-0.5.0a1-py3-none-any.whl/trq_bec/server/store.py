"""PostgreSQL durable state and append-only evidence ledger."""

from __future__ import annotations

import base64
import time
import uuid
from typing import Any, Protocol

from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from psycopg_pool import ConnectionPool

from ..canonical import domain_message, sha3_hex
from ..contracts import CryptoEnvelope, Intent
from ..errors import LedgerError
from ..ledger.ledger import _validate_sanitized
from .models import AuditRecord, CouponRecord, DeviceRecord, OperationRecord, TokenRecord


AUDIT_LOCK_ID = 0x545251424543
ZERO_HASH = "0" * 64


class StoreConflict(RuntimeError):
    pass


class StoreNotFound(RuntimeError):
    pass


class DurableStore(Protocol):
    def ping(self) -> bool: ...
    def enroll_device(self, uid: str, key_id: str, public_key_b64u: str, algorithm: str, storage_profile: str) -> tuple[DeviceRecord, bool]: ...
    def get_device(self, uid: str, key_id: str) -> DeviceRecord | None: ...
    def get_coupon_for_issue(self, coupon_id: str, owner_uid: str) -> CouponRecord | None: ...
    def store_token(self, token: TokenRecord) -> None: ...
    def get_token(self, token_ref: str) -> TokenRecord | None: ...
    def create_operation(self, operation: OperationRecord) -> None: ...
    def get_operation(self, operation_id: str) -> OperationRecord | None: ...
    def append_audit(self, **kwargs: Any) -> AuditRecord: ...
    def finalize_authorization(self, operation_id: str, token_ref: str, decision: str, result: dict[str, Any], **audit: Any) -> AuditRecord: ...
    def create_checkpoint(self, checkpoint_key_id: str, policy_version: str) -> dict[str, Any]: ...


class PostgresStore:
    def __init__(self, pool: ConnectionPool, signing_provider) -> None:
        self.pool = pool
        self.signing_provider = signing_provider

    def ping(self) -> bool:
        with self.pool.connection() as conn:
            return conn.execute("SELECT 1 AS ok").fetchone()["ok"] == 1

    def enroll_device(
        self,
        uid: str,
        key_id: str,
        public_key_b64u: str,
        algorithm: str,
        storage_profile: str,
    ) -> tuple[DeviceRecord, bool]:
        with self.pool.connection() as conn, conn.transaction():
            existing = conn.execute(
                "SELECT * FROM device_keys WHERE device_key_id = %s FOR UPDATE",
                (key_id,),
            ).fetchone()
            if existing:
                if (
                    existing["firebase_uid"] != uid
                    or existing["public_key_b64u"] != public_key_b64u
                    or existing["algorithm"] != algorithm
                    or existing["status"] != "ACTIVE"
                ):
                    raise StoreConflict("DEVICE_KEY_BINDING_CONFLICT")
                conn.execute("UPDATE device_keys SET last_seen_at = now() WHERE device_key_id = %s", (key_id,))
                return self._device(existing), False
            try:
                row = conn.execute(
                    """
                    INSERT INTO device_keys
                      (device_key_id, firebase_uid, public_key_b64u, algorithm, storage_profile)
                    VALUES (%s, %s, %s, %s, %s)
                    RETURNING *
                    """,
                    (key_id, uid, public_key_b64u, algorithm, storage_profile),
                ).fetchone()
            except Exception as exc:
                raise StoreConflict("DEVICE_PUBLIC_KEY_ALREADY_BOUND") from exc
            return self._device(row), True

    @staticmethod
    def _device(row: dict[str, Any]) -> DeviceRecord:
        return DeviceRecord(
            firebase_uid=row["firebase_uid"],
            device_key_id=row["device_key_id"],
            public_key_b64u=row["public_key_b64u"],
            algorithm=row["algorithm"],
            status=row["status"],
        )

    def get_device(self, uid: str, key_id: str) -> DeviceRecord | None:
        with self.pool.connection() as conn:
            row = conn.execute(
                "SELECT * FROM device_keys WHERE firebase_uid = %s AND device_key_id = %s AND status = 'ACTIVE'",
                (uid, key_id),
            ).fetchone()
        return self._device(row) if row else None

    def get_coupon_for_issue(self, coupon_id: str, owner_uid: str) -> CouponRecord | None:
        with self.pool.connection() as conn:
            row = conn.execute(
                """
                SELECT coupon_id, owner_uid, active,
                       CASE WHEN valid_until IS NULL THEN NULL ELSE EXTRACT(EPOCH FROM valid_until)::BIGINT END AS valid_until
                FROM coupon_definitions
                WHERE coupon_id = %s AND active = TRUE
                  AND (owner_uid IS NULL OR owner_uid = %s)
                  AND (valid_until IS NULL OR valid_until > now())
                """,
                (coupon_id, owner_uid),
            ).fetchone()
        return CouponRecord(**row) if row else None

    def store_token(self, token: TokenRecord) -> None:
        envelope = CryptoEnvelope.from_dict(token.envelope)
        with self.pool.connection() as conn, conn.transaction():
            conn.execute(
                """
                INSERT INTO coupon_tokens
                  (token_ref, jti, issuer_uid, issuer_ref, coupon_id, intent_json, envelope_json,
                   policy_version, expires_at, status, redeemed_operation_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, to_timestamp(%s), %s, %s)
                """,
                (
                    token.token_ref,
                    envelope.jti,
                    token.issuer_uid,
                    token.issuer_ref,
                    token.coupon_id,
                    Jsonb(token.intent),
                    Jsonb(token.envelope),
                    envelope.policy_version,
                    token.expires_at,
                    token.status,
                    token.redeemed_operation_id,
                ),
            )

    def get_token(self, token_ref: str) -> TokenRecord | None:
        with self.pool.connection() as conn:
            row = conn.execute(
                """
                SELECT token_ref, issuer_uid, issuer_ref, coupon_id, intent_json AS intent,
                       envelope_json AS envelope, EXTRACT(EPOCH FROM expires_at)::BIGINT AS expires_at,
                       status, redeemed_operation_id
                FROM coupon_tokens WHERE token_ref = %s
                """,
                (token_ref,),
            ).fetchone()
        return TokenRecord(**row) if row else None

    def create_operation(self, operation: OperationRecord) -> None:
        with self.pool.connection() as conn, conn.transaction():
            conn.execute(
                """
                INSERT INTO redemption_operations
                  (operation_id, firebase_uid, session_id, token_ref, device_key_id,
                   challenge_id, expires_at, status, result_json)
                VALUES (%s, %s, %s, %s, %s, %s, to_timestamp(%s), %s, %s)
                """,
                (
                    operation.operation_id,
                    operation.firebase_uid,
                    operation.session_id,
                    operation.token_ref,
                    operation.device_key_id,
                    operation.challenge_id,
                    operation.expires_at,
                    operation.status,
                    Jsonb(operation.result) if operation.result else None,
                ),
            )

    def get_operation(self, operation_id: str) -> OperationRecord | None:
        with self.pool.connection() as conn:
            row = conn.execute(
                """
                SELECT operation_id, firebase_uid, session_id, token_ref, device_key_id,
                       challenge_id, EXTRACT(EPOCH FROM expires_at)::BIGINT AS expires_at,
                       status, result_json AS result
                FROM redemption_operations WHERE operation_id = %s
                """,
                (operation_id,),
            ).fetchone()
        return OperationRecord(**row) if row else None

    def _append_audit_conn(
        self,
        conn,
        *,
        operation_id: str,
        suite_id: str,
        key_ref_token: str,
        event_type: str,
        result: str,
        reason_codes: tuple[str, ...] = (),
        evidence_refs: tuple[str, ...] = (),
        details: dict[str, Any] | None = None,
    ) -> AuditRecord:
        details = details or {}
        _validate_sanitized(details)
        conn.execute("SELECT pg_advisory_xact_lock(%s)", (AUDIT_LOCK_ID,))
        previous = conn.execute(
            "SELECT seq, event_hash FROM audit_events ORDER BY seq DESC LIMIT 1",
        ).fetchone()
        seq = int(previous["seq"]) + 1 if previous else 1
        prev_hash = previous["event_hash"] if previous else ZERO_HASH
        event_id = str(uuid.uuid4())
        body = {
            "event_id": event_id,
            "seq": seq,
            "operation_id": operation_id,
            "suite_id": suite_id,
            "key_ref_token": key_ref_token,
            "event_type": event_type,
            "result": result,
            "reason_codes": list(reason_codes),
            "evidence_refs": list(evidence_refs),
            "details": details,
            "prev_hash": prev_hash,
        }
        event_hash = sha3_hex(body, "TRQ-BEC/audit/v1")
        conn.execute(
            """
            INSERT INTO audit_events
              (seq, event_id, operation_id, suite_id, key_ref_token, event_type, result,
               reason_codes, evidence_refs, details_json, prev_hash, event_hash)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                seq,
                event_id,
                operation_id,
                suite_id,
                key_ref_token,
                event_type,
                result,
                Jsonb(list(reason_codes)),
                Jsonb(list(evidence_refs)),
                Jsonb(details),
                prev_hash,
                event_hash,
            ),
        )
        return AuditRecord(event_id=f"event:{event_id}", seq=seq, event_hash=event_hash)

    def append_audit(self, **kwargs: Any) -> AuditRecord:
        try:
            with self.pool.connection() as conn, conn.transaction():
                return self._append_audit_conn(conn, **kwargs)
        except Exception as exc:
            raise LedgerError("POSTGRES_LEDGER_APPEND_FAILED") from exc

    def finalize_authorization(
        self,
        operation_id: str,
        token_ref: str,
        decision: str,
        result: dict[str, Any],
        **audit: Any,
    ) -> AuditRecord:
        with self.pool.connection() as conn, conn.transaction():
            operation = conn.execute(
                "SELECT status, result_json FROM redemption_operations WHERE operation_id = %s FOR UPDATE",
                (operation_id,),
            ).fetchone()
            if not operation:
                raise StoreNotFound("OPERATION_NOT_FOUND")
            if operation["status"] == "COMPLETED" and operation["result_json"]:
                raise StoreConflict("OPERATION_ALREADY_COMPLETED")

            status = {
                "ALLOW": "COMPLETED",
                "STEP_UP": "STEP_UP_REQUIRED",
                "HOLD_OR_REVIEW": "HELD",
                "DENY": "DENIED",
            }[decision]

            if decision == "ALLOW":
                updated = conn.execute(
                    """
                    UPDATE coupon_tokens
                    SET status = 'REDEEMED', redeemed_at = now(), redeemed_operation_id = %s
                    WHERE token_ref = %s AND status = 'ISSUED' AND expires_at > now()
                    RETURNING token_ref
                    """,
                    (operation_id, token_ref),
                ).fetchone()
                if not updated:
                    raise StoreConflict("TOKEN_ALREADY_USED_OR_EXPIRED")
            elif decision == "HOLD_OR_REVIEW":
                conn.execute(
                    "UPDATE coupon_tokens SET status = 'HELD', redeemed_operation_id = %s WHERE token_ref = %s AND status = 'ISSUED'",
                    (operation_id, token_ref),
                )

            event = self._append_audit_conn(conn, operation_id=operation_id, result=decision, **audit)
            result_with_event = {**result, "event_ref": event.event_id}
            conn.execute(
                """
                UPDATE redemption_operations
                SET status = %s, result_json = %s, completed_at = now()
                WHERE operation_id = %s
                """,
                (status, Jsonb(result_with_event), operation_id),
            )
            return event

    def create_checkpoint(self, checkpoint_key_id: str, policy_version: str) -> dict[str, Any]:
        with self.pool.connection() as conn, conn.transaction():
            conn.execute("SELECT pg_advisory_xact_lock(%s)", (AUDIT_LOCK_ID,))
            first = conn.execute("SELECT seq FROM audit_events ORDER BY seq ASC LIMIT 1").fetchone()
            last = conn.execute("SELECT seq, event_hash FROM audit_events ORDER BY seq DESC LIMIT 1").fetchone()
            if not first or not last:
                raise LedgerError("LEDGER_EMPTY")
            body = {
                "first_seq": int(first["seq"]),
                "last_seq": int(last["seq"]),
                "root_hash": last["event_hash"],
                "policy_version": policy_version,
            }
            signature = self.signing_provider.sign(
                checkpoint_key_id,
                domain_message("TRQ-BEC/checkpoint/v1", body),
                "checkpoint-signing",
            )
            signature_b64u = base64.urlsafe_b64encode(signature).rstrip(b"=").decode("ascii")
            checkpoint_id = str(uuid.uuid4())
            conn.execute(
                """
                INSERT INTO audit_checkpoints
                  (checkpoint_id, first_seq, last_seq, root_hash, policy_version, signature_b64u)
                VALUES (%s, %s, %s, %s, %s, %s)
                """,
                (checkpoint_id, body["first_seq"], body["last_seq"], body["root_hash"], policy_version, signature_b64u),
            )
            return {**body, "checkpoint_id": checkpoint_id, "signature_b64u": signature_b64u}
