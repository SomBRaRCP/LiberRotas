"""FastAPI transport for the app_LiberRotas TRQ-BEC backend."""

from __future__ import annotations

import uuid
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .. import __version__
from .auth import Authenticator, require_principal
from .config import ServerSettings, get_settings
from .models import (
    AuthorizationResponse,
    AuthorizeRedemptionRequest,
    BeginRedemptionRequest,
    BeginRedemptionResponse,
    EnrollDeviceRequest,
    EnrollDeviceResponse,
    HealthResponse,
    IssueCouponRequest,
    IssueCouponResponse,
    Principal,
)
from .runtime import Runtime, build_runtime
from .service import CouponSecurityService, ServiceError


def create_app(
    settings: ServerSettings | None = None,
    *,
    service_override: CouponSecurityService | None = None,
    authenticator_override: Authenticator | None = None,
) -> FastAPI:
    settings = settings or get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        runtime: Runtime | None = None
        if service_override is not None and authenticator_override is not None:
            app.state.service = service_override
            app.state.authenticator = authenticator_override
            app.state.pqc_provider = service_override.pqc_provider
        else:
            runtime = build_runtime(settings)
            app.state.service = runtime.service
            app.state.authenticator = runtime.authenticator
            app.state.pqc_provider = runtime.pqc_provider
        yield
        if runtime is not None:
            runtime.close()

    app = FastAPI(
        title="TRQ-BEC LiberRotas API",
        version=__version__,
        docs_url="/docs" if settings.docs_enabled and settings.environment != "production" else None,
        redoc_url=None,
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["authorization", "content-type", "x-request-id"],
    )

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
        response = await call_next(request)
        response.headers["x-request-id"] = request_id[:128]
        response.headers["x-content-type-options"] = "nosniff"
        response.headers["cache-control"] = "no-store"
        response.headers["referrer-policy"] = "no-referrer"
        return response

    @app.exception_handler(ServiceError)
    async def service_error_handler(_: Request, exc: ServiceError):
        return JSONResponse(
            status_code=exc.status_code,
            content={"code": exc.code, "message": exc.message},
            headers={"cache-control": "no-store"},
        )

    def service(request: Request) -> CouponSecurityService:
        return request.app.state.service

    @app.get("/health/", response_model=HealthResponse)
    def health(request: Request) -> HealthResponse:
        return service(request).health()

    @app.get("/health/crypto")
    def crypto_health(request: Request):
        status = request.app.state.pqc_provider.status()
        return {
            "provider": status.name,
            "version": status.version,
            "approved": status.approved,
            "self_test_passed": status.self_test_passed,
            "ml_kem_768": status.ml_kem_768,
            "ml_dsa_65": status.ml_dsa_65,
            "ready": status.ready,
        }

    @app.post("/v1/trq-bec/devices/enroll", response_model=EnrollDeviceResponse)
    def enroll_device(
        payload: EnrollDeviceRequest,
        request: Request,
        principal: Principal = Depends(require_principal),
    ) -> EnrollDeviceResponse:
        return service(request).enroll_device(principal, payload)

    @app.post("/v1/trq-bec/coupons/issue", response_model=IssueCouponResponse)
    def issue_coupon(
        payload: IssueCouponRequest,
        request: Request,
        principal: Principal = Depends(require_principal),
    ) -> IssueCouponResponse:
        return service(request).issue_coupon(principal, payload)

    @app.post("/v1/trq-bec/coupons/redeem/begin", response_model=BeginRedemptionResponse)
    def begin_redemption(
        payload: BeginRedemptionRequest,
        request: Request,
        principal: Principal = Depends(require_principal),
    ) -> BeginRedemptionResponse:
        return service(request).begin_redemption(principal, payload)

    @app.post("/v1/trq-bec/coupons/redeem/authorize", response_model=AuthorizationResponse)
    def authorize_redemption(
        payload: AuthorizeRedemptionRequest,
        request: Request,
        principal: Principal = Depends(require_principal),
    ) -> AuthorizationResponse:
        return service(request).authorize_redemption(principal, payload)

    @app.post("/internal/v1/ledger/checkpoint")
    def create_checkpoint(
        request: Request,
        principal: Principal = Depends(require_principal),
    ):
        return service(request).checkpoint(principal)

    return app


app = create_app()
